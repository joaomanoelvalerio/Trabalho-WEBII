import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ClienteHomeComponent } from './client-home';

describe('ClienteHomeComponent', () => {
  let component: ClienteHomeComponent;
  let fixture: ComponentFixture<ClienteHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClienteHomeComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ClienteHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
